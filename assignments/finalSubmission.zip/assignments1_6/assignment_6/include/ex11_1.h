/*
Course name: Linux and C Programming (62558)
Student name: Mads Richardt
Student Id: s224849
Date: 17-11-2022
*/

#ifndef EX11_1
#define EX11_1

// Function for running exercise 11.1
void ex11_1();

#endif 
