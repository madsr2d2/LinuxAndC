/*
Course name: Linux and C Programming (62558)
Student name: Mads Richardt
Student Id: s224849
Date: 17-11-2022
*/

#ifndef FACTORIAL
#define FACTORIAL

// Computes the factorial.
unsigned long factorial(unsigned long n);

#endif