---
title:  Mandatory Assignment 3
subtitle: 'Linux and C Programming (62558)'
author: Mads Richardt (s224948)
date: \today
documentclass: scrartcl
---

# Introduction
The aim of this assignment is to introduce the student to Make[^1]. Make is a build automation tool that enables automatic compilation of executable programs from source code. This is done by reading so called Makefiles, which specify how target program should be compiled. Makefiles are just a standard text files read by the Make program and their main component are so called *build rules*. These rules specify the dependencies of a particular file, the *target*, and how the compiler should build this file from these dependencies. In this assignment, the student must generate a Makefile which automates the build process of an executable program from source code. I addition,  the Makefile and the source code must be uploaded to the student server using SCP.

# Source Code, Makefile and Project Folder Layout
As source code, I have the chosen assignment 6 from the course thought by Ole Schults. I this assignment, we wrote a small program that counts the number of times elements from on string appears in another string. The code was written using Visual Studio Code and the project folder layout and MakeFile was generated using the C/C++ Project Generator[^2] extension. The project folder, A3, has the following layout.

```
A3
|_docs/
|_include/
|_src/
|_output/
|_Makefile
```
The Makefile is located in the A3 directory.  The A3/docs directory contains the present document in pdf and Markdown format. The A3/include and A3/src directories contain .h and .c files, respectively. The A3/output directory will contain the executable program, **hnp_a6**, when successfully compiled.

# SCP to Student Server



```
madsrichardt@penguin:~$ ls
Arduino  bin  Desktop  sem1
madsrichardt@penguin:~$ cd sem1/
madsrichardt@penguin:~/sem1$ 
```

[^1]: https://www.gnu.org/software/make/
[^2]: https://marketplace.visualstudio.com/items?itemName=danielpinto8zz6.c-cpp-project-generator