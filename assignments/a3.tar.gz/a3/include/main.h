#if !defined(MAIN_H)
#define MAIN_H


#include <stdio.h>
#include "countCharactersInSet.h"
#include "get_double.h"


#endif
