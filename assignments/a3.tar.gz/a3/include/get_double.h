#ifndef GET_DOUBLE_H
#define GET_DOUBLE_H

double get_double(char[], unsigned long, unsigned long);
void clear_stdin(void);

#endif