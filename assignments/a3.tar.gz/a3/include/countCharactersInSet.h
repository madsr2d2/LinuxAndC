#ifndef COUNT_CHARACTER_IN_SET_H
#define COUNT_CHARACTER_IN_SET_H

int countCharactersInSet(const char * text, const char * set);

#endif